# README

## bin文件夹含有可执行程序 -- Edge_detector.exe
执行命令：`./Edge_detector XXX.bmp sigma tlow thigh`

## src文件夹包含源程序