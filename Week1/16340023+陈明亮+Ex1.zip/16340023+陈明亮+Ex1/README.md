### 作业1文件结构
	16340023+陈明亮+Ex1
	│ 
	├── bin
	│   ├─ Ex1-cimg.exe
	│   ├─ Ex1.exe
	│
	├── src
	│   ├─ Ex1.cpp
	│   ├─ Ex1-cimg.cpp
	│	├─ CImg.h
	│	├─ 1.bmp
	│
	├── Ex1+99.5.txt
	│
	├── Homework1.pdf
	
   	

### 作业1文件详情
1. 代码文件
* CImg.h
* Ex1-cimg.cpp 为采用CImg类接口处理图像像素的源程序文件
* Ex1.cpp 为采用自己编写的逻辑处理图像像素的源程序文件

2. 可执行文件
* Ex1-cimg.exe 为编译Ex1-cimg.cpp后生成的可执行文件(Windows环境下编译)
* Ex1.exe 位编译Ex1.cpp后生成的可执行文件(Windows环境下编译)

3. 其他文件
* Homework1.pdf 作业一实验报告(结合测试文档)
* Ex1+100.txt 自我评分文件
* 1.bmp 测试图像